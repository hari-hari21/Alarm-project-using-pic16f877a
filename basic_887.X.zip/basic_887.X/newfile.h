/* 
 * File:   newfile.h
 * Author: Home
 *
 * Created on 11 November, 2024, 4:01 PM
 */

#ifndef NEWFILE_H
#define	NEWFILE_H
#define aa 10
#ifdef	__cplusplus
extern "C" 
{
#endif




#ifdef	__cplusplus
}
#endif

#endif	/* NEWFILE_H */

