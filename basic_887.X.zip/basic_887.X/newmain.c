// PIC16F877A Configuration Bit Settings

// CONFIG
#pragma config FOSC = HS        // High-Speed Oscillator
#pragma config WDTE = OFF       // Watchdog Timer Enable (WDT disabled)
#pragma config PWRTE = OFF      // Power-up Timer Enable (PWRT disabled)
#pragma config BOREN = ON       // Brown-out Reset Enable (BOR enabled)
#pragma config LVP = OFF        // Low-Voltage ICSP (RB3 is digital I/O, HV on MCLR for programming)
#pragma config CPD = OFF        // Data EEPROM Memory Code Protection (Off)
#pragma config WRT = OFF        // Flash Program Memory Write Enable (Off)
#pragma config CP = OFF         // Flash Program Memory Code Protection (Off)


// Include necessary headers
#include <xc.h>
// Define clock frequency
#define _XTAL_FREQ 10000000
    #define rs RC0
    #define rw RC1
    #define en RC2
    #define sec 0x00
    #define min 0x01
    #define hour 0x02
    #define delay for(j=0;j<1000;j++)

    int state = 0;
    int seconds;
    int minute;
    int alarm = 0;
    int hours;
    int tempseconds;
    int tempminute;
    int temphours = 1;;    
    int j;

    void lcd_init();
    void cmd(unsigned char a);
    void dat(unsigned char b);
    void show(unsigned char *s);
    
void start()
{
    SSPCON2bits.SEN = 1;
    while(SSPIF == 0);
    SSPIF = 0;
}
void stop()
{
    SSPCON2bits.PEN = 1;
    while(SSPIF == 0);
    SSPIF = 0;
    
}
void write(char data)
{
    SSPBUF = data;
    while(SSPIF == 0);
    SSPIF = 0;
}
void I2C_Master_RepeatedStart()
{
  SSPCON2bits.RSEN = 1;
  while(SSPIF==0);
  SSPIF=0;
}
unsigned short read(int data)
{
  unsigned long int temp;
  RCEN = 1;
  while(SSPIF==0);
  SSPIF=0;
  temp = SSPBUF; 
  if(data==0)
   ACKDT =1;
  else
   ACKDT =0;
  ACKEN = 1;
  while(SSPIF==0);
  SSPIF=0;
  return temp;
}
int readsq(char add)
{
    start();
    write(0xd0);
    write(add);
    I2C_Master_RepeatedStart();
    write(0xd1);
    int value = bcd_dec(read(0));
    stop();
    return value;
}
void writesq(int data,char add)
{
    start();
    write(0xd0);
    write(add);
    write(int_to_bcd(data));
    stop();
}
int int_to_bcd(int value)
{
    int i = ((value/10)<<4)+value%10;
    return i;
}

int bcd_dec( int data)
{
    int result;
   result=(((data>>4)*10)+(data&0x0f));
   return result;
}
 void numbershow()
    {
        cmd(0x06);
        dat((seconds/10)%10+'0');
        dat(seconds%10+'0');
        dat('-');
        dat((minute/10)%10+'0');
        dat(minute%10+'0');
        dat('-');
        dat((hours/10)%10+'0');
        dat(hours%10+'0');
    }
 void showhours()
 {
     
         cmd(0x87);
        dat((temphours/10)%10+'0');
         cmd(0x88);
        dat(temphours%10+'0');
        

 }
 void showmintue()
 {
        cmd(0x8A);
        dat((tempminute/10)%10+'0');
        cmd(0x8B);
        dat(tempminute%10+'0');
 }
 void showsec()
 {
        cmd(0x8D);
        dat((tempseconds/10)%10+'0');
        cmd(0x8E);
        dat(tempseconds%10+'0');    
 }
void time()
{
     cmd(0x80); //forcing the cursor at 0x8A position
     show("time : ");
     seconds = readsq(sec);
     minute = readsq(min);
     hours   = readsq(hour);
     numbershow();
}
void main()
{
    SSPCON = 0b00101000;
    SSPADD = 0x3f;
    TRISB=TRISC0=TRISC1=TRISC2= TRISA0 = 0;
    TRISD0 = TRISD1 = TRISD2 = 1;
    RD0 = RD1 = RD2 = RA0 = 0;
    TRISD0 = 1;
    lcd_init();
    
    while(1)
    {
        if(state == 0)
        {
          time();
          if(alarm == 1 && temphours == hours && tempseconds == seconds && tempminute == minute)
          {
              RA0 = 1;
              temphours = tempseconds = tempminute = 0;
          }
          while(RD0 == 1)
              state = 1;
          
          
        }
        else if(state == 1)
        {
            
            cmd(0x80);
            show("set  : 00-00-00");
            while(state == 1)
            {
//                
//                cmd(0x87);
//                show("  ");
//                 __delay_ms(500);
//                cmd(0x87);
                showhours();
//                 __delay_ms(500);
                 
                 if(RD1 == 1)
                 {
                     while(RD1 == 1);
                     temphours++;
                    
                 }
                 if(temphours >= 12)
                     temphours = 0;
                 
                 while(RD0 == 1)
                 {
                     state = 2;
                 }
            }
            
        }
        else if(state == 2)
        {
            cmd(0x80);
            show("set  : ");
            showhours();
  
            while(state == 2)
            {
                
//                cmd(0x8A);
//                show("  ");
//                 __delay_ms(500);
//                cmd(0x8A);
                showmintue();
//                 __delay_ms(500);
                 
                 if(RD1 == 1)
                 {
                     while(RD1 == 1);
                     tempminute++;
                    
                 }
                 if(tempminute >= 60)
                     tempminute = 0;
                 
                 while(RD0 == 1)
                 {
                     state = 3;
                 }                 
            }
            
        }
        else if(state == 3)
        {
//            cmd(0x80);
//            show("sett : ");
            showhours();
            showmintue();
  
            while(state == 3)
            {
                
//                cmd(0x8D);
//                show("  ");
//                 __delay_ms(500);
//                cmd(0x8D);
                showsec();
//                 __delay_ms(500);
                 
                 if(RD1 == 1)
                 {
                     while(RD1 == 1);
                     tempseconds++;
                    
                 }
                 if(tempseconds >= 60)
                     tempseconds = 0;
                 
                 while(RD2 == 1)
                 {
                     state = 4;
                 }                 
            }
        }
        else if(state == 4 )
        {
            while(state == 4)
            {
                if(RD2 == 1)
                {
                  cmd(0x80);
                  show("SUCCESSFULL....");
                  __delay_ms(2000);
                  state = 0;
                  alarm = 1;
                  break;
                }
                
                
            }
        }

    }
    
}

void lcd_init()
    {
        cmd(0x38);
        cmd(0x0c);
    }

    void cmd(unsigned char a)
    {
        PORTB=a;
        rs=0;
        rw=0;
        en=1;
        delay;
        en=0;
    }

    void dat(unsigned char b)
    {
        PORTB=b;
        rs=1;
        rw=0;
        en=1;
        delay;
        en=0;
    }

    void show(unsigned char *s)
    {
        while(*s) {
            dat(*s++);
        }
    }